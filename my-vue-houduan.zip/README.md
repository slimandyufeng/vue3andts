# GrapesJS JSON 解析与渲染服务

这是一个基于 Node.js 和 Egg.js 框架的后端服务，用于解析和渲染 GrapesJS 导出的 JSON 数据。

## 功能特性

- **JSON 解析**：高效解析从 GrapesJS 导出的 JSON 数据
- **模板渲染**：支持两种渲染方式：GrapesJS 原生和模板语法
- **性能优化**：使用流式处理方式处理大型 JSON 数据
- **性能监控**：提供渲染时间统计和性能评级（低于100ms为优，高于100ms为不及格）
- **跨域支持**：配置 CORS 中间件处理跨域请求
- **Mock 数据**：提供多种类型的模拟数据用于测试

## 技术栈

- Node.js
- Egg.js 框架
- JSDOM（用于 DOM 操作和渲染）
- 自定义模板引擎（支持变量、条件、循环等特性）
- Stream-JSON（流式 JSON 处理）
- Nunjucks（视图引擎）

## 快速开始

### 安装依赖

```bash
npm install
```

### 启动开发服务器

```bash
npm run dev
```

### 生产环境启动

```bash
npm start
```

### 停止服务

```bash
npm stop
```

## API 文档

### 获取模拟数据

```
GET /api/mock-data?type=[grapesjs|xtemplate|mixed]
```

参数：
- `type`: 模拟数据类型，可选值为 `grapesjs`、`xtemplate` 或 `mixed`

返回：GrapesJS JSON 数据

### 解析 JSON 文件

```
POST /api/parse-json
```

请求：
- Content-Type: multipart/form-data
- 文件字段名: jsonFile

返回：
```json
{
  "success": true,
  "data": {
    "components": [...],
    "styles": {...},
    "type": "grapesjs 或 xtemplate"
  }
}
```

### 渲染模板

```
POST /api/render-template
```

请求体：
```json
{
  "components": [...],
  "templateType": "grapesjs 或 xtemplate"
}
```

返回：
```json
{
  "success": true,
  "html": "渲染后的 HTML",
  "performance": {
    "renderTime": 42,
    "rating": "优"
  }
}
```

## 渲染逻辑说明

### GrapesJS 原生渲染

使用 JSDOM 在服务端创建 DOM 元素，根据组件结构递归构建 DOM 树，最终生成 HTML。

### 模板语法渲染

将组件转换为标准 HTML 字符串，然后使用自定义的模板引擎进行渲染：

- **变量替换**：`{{变量名}}` 将被替换为对应的数据值
- **条件渲染**：支持 `{{#if 条件}}...{{else}}...{{/if}}` 语法
- **循环渲染**：支持 `{{#each 数组}}...{{/each}}` 语法

## 性能优化与监控

- 使用 Stream-JSON 进行流式解析，避免一次性加载大型 JSON 到内存
- 按需解析 JSON 字段，减少内存占用
- 使用高效的 DOM 操作库和自定义模板引擎
- 实现了轻量级的模板替换算法，无需依赖大型模板库
- **性能监控**：每次渲染都会返回渲染时间和性能评级
  - 渲染时间低于 100ms：评级为"优"
  - 渲染时间高于 100ms：评级为"不及格"
- 提供批量测试工具，支持多次渲染计算平均性能

## 项目目录结构

```
.
├── app
│   ├── controller          # 控制器
│   ├── middleware          # 中间件
│   ├── public              # 静态资源
│   │   └── mock            # 模拟数据
│   ├── service             # 服务层
│   └── view                # 视图模板
├── config                  # 配置文件
│   ├── config.default.js   # 默认配置
│   └── plugin.js           # 插件配置
└── package.json            # 项目依赖
```

## 注意事项

- 大型 JSON 处理时需要确保服务器有足够的内存
- 请求大小限制默认设置为 50MB，可在配置中调整
- 自定义模板引擎支持基本的模板特性，但不支持复杂的嵌套条件和高级表达式 