'use strict';

/** @type Egg.EggPlugin */
module.exports = {
  // 启用 CORS 插件
  cors: {
    enable: true,
    package: 'egg-cors',
  },
  // 启用 Nunjucks 模板引擎
  nunjucks: {
    enable: true,
    package: 'egg-view-nunjucks',
  },
}; 