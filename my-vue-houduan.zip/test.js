const http = require('http');
const fs = require('fs');

async function runTests() {
  console.log('开始测试 GrapesJS JSON 解析与渲染服务...');
  
  // 测试获取 GrapesJS 模拟数据
  console.log('\n1. 测试获取 GrapesJS 原生组件数据');
  const grapesJsData = await fetchMockData('grapesjs');
  console.log(`- 获取成功，组件数量: ${grapesJsData.components.length}`);
  
  // 测试获取 XTemplate 模拟数据
  console.log('\n2. 测试获取 XTemplate 组件数据');
  const xTemplateData = await fetchMockData('xtemplate');
  console.log(`- 获取成功，组件数量: ${xTemplateData.components.length}`);
  
  // 测试获取混合模拟数据
  console.log('\n3. 测试获取混合组件数据');
  const mixedData = await fetchMockData('mixed');
  console.log(`- 获取成功，组件数量: ${mixedData.components.length}`);
  
  // 测试渲染 GrapesJS 模板
  console.log('\n4. 测试渲染 GrapesJS 原生组件');
  const grapesJsRender = await renderTemplate(grapesJsData.components, 'grapesjs');
  console.log(`- 渲染成功，HTML 长度: ${grapesJsRender.html.length}`);
  if (grapesJsRender.performance) {
    console.log(`- 渲染性能: ${grapesJsRender.performance.renderTime}ms (${grapesJsRender.performance.rating})`);
  }
  
  // 测试渲染 XTemplate 模板
  console.log('\n5. 测试渲染 XTemplate 组件');
  const xTemplateRender = await renderTemplate(xTemplateData.components, 'xtemplate');
  console.log(`- 渲染成功，HTML 长度: ${xTemplateRender.html.length}`);
  if (xTemplateRender.performance) {
    console.log(`- 渲染性能: ${xTemplateRender.performance.renderTime}ms (${xTemplateRender.performance.rating})`);
  }
  
  // 性能测试 - 多次渲染并计算平均时间
  console.log('\n6. 进行渲染性能测试 (10次)');
  const iterations = 10;
  let totalGrapesJsTime = 0;
  let totalXTemplateTime = 0;
  
  for (let i = 0; i < iterations; i++) {
    const grapesJsResult = await renderTemplate(grapesJsData.components, 'grapesjs');
    const xTemplateResult = await renderTemplate(xTemplateData.components, 'xtemplate');
    
    totalGrapesJsTime += grapesJsResult.performance.renderTime;
    totalXTemplateTime += xTemplateResult.performance.renderTime;
    
    process.stdout.write('.');
  }
  
  const avgGrapesJsTime = totalGrapesJsTime / iterations;
  const avgXTemplateTime = totalXTemplateTime / iterations;
  
  console.log('\n- GrapesJS 平均渲染时间: ' + avgGrapesJsTime.toFixed(2) + 'ms (' + (avgGrapesJsTime < 100 ? '优' : '不及格') + ')');
  console.log('- XTemplate 平均渲染时间: ' + avgXTemplateTime.toFixed(2) + 'ms (' + (avgXTemplateTime < 100 ? '优' : '不及格') + ')');
  
  console.log('\n所有测试完成！服务工作正常。');
}

async function fetchMockData(type) {
  return new Promise((resolve, reject) => {
    http.get(`http://localhost:7001/api/mock-data?type=${type}`, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (error) {
          reject(error);
        }
      });
    }).on('error', (error) => {
      reject(error);
    });
  });
}

async function renderTemplate(components, templateType) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify({
      components: components,
      templateType: templateType
    });
    
    const options = {
      hostname: 'localhost',
      port: 7001,
      path: '/api/render-template',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    };
    
    const req = http.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (error) {
          reject(error);
        }
      });
    });
    
    req.on('error', (error) => {
      reject(error);
    });
    
    req.write(postData);
    req.end();
  });
}

// 等待服务器启动后运行测试
setTimeout(() => {
  runTests().catch(error => {
    console.error('测试出错:', error);
  });
}, 3000); 