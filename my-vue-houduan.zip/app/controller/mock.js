'use strict';

const Controller = require('egg').Controller;
const fs = require('fs').promises;
const path = require('path');

class MockController extends Controller {
  /**
   * 获取模拟的 GrapesJS JSON 数据
   */
  async getData() {
    const { ctx } = this;
    const { type = 'mixed' } = ctx.query;
    let mockDataPath;
    
    // 根据请求的类型返回不同的模拟数据
    switch (type) {
      case 'grapesjs':
        mockDataPath = path.join(this.app.baseDir, 'app/public/mock/grapesjs-mock.json');
        break;
      case 'xtemplate':
        mockDataPath = path.join(this.app.baseDir, 'app/public/mock/xtemplate-mock.json');
        break;
      case 'mixed':
      default:
        mockDataPath = path.join(this.app.baseDir, 'app/public/mock/mixed-mock.json');
        break;
    }
    
    try {
      // 尝试读取模拟数据文件
      const data = await fs.readFile(mockDataPath, 'utf8');
      ctx.body = JSON.parse(data);
    } catch (error) {
      // 如果文件不存在，则生成模拟数据
      ctx.logger.info('模拟数据文件不存在，生成新的模拟数据');
      const mockData = await this.service.mock.generateMockData(type);
      
      // 确保目录存在
      await fs.mkdir(path.dirname(mockDataPath), { recursive: true });
      
      // 将生成的数据保存到文件中
      await fs.writeFile(mockDataPath, JSON.stringify(mockData, null, 2));
      
      ctx.body = mockData;
    }
  }
}

module.exports = MockController; 