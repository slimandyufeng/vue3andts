'use strict';

const Controller = require('egg').Controller;

class HomeController extends Controller {
  async index() {
    const { ctx } = this;
    await ctx.render('index.html', {
      title: 'GrapesJS JSON 解析与渲染服务',
    });
  }
}

module.exports = HomeController; 