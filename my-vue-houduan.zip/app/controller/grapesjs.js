'use strict';

const Controller = require('egg').Controller;
const fs = require('fs');
const stream = require('stream');
const { promisify } = require('util');
const pipeline = promisify(stream.pipeline);

class GrapesjsController extends Controller {
  /**
   * 解析上传的 GrapesJS JSON 文件
   */
  async parseJson() {
    const { ctx, service } = this;
    const file = ctx.request.files[0];
    
    if (!file) {
      ctx.status = 400;
      ctx.body = { success: false, message: '未找到上传的文件' };
      return;
    }
    
    try {
      // 使用 stream 读取大型 JSON 文件
      const jsonData = await service.grapesjs.parseJsonStream(file.filepath);
      
      // 清理临时文件
      await fs.promises.unlink(file.filepath);
      
      ctx.body = {
        success: true,
        data: {
          components: jsonData.components,
          styles: jsonData.styles,
          type: service.grapesjs.detectTemplateType(jsonData)
        }
      };
    } catch (error) {
      ctx.logger.error('解析 JSON 出错:', error);
      ctx.status = 500;
      ctx.body = { success: false, message: '解析 JSON 出错: ' + error.message };
    }
  }
  
  /**
   * 渲染模板
   */
  async renderTemplate() {
    const { ctx, service } = this;
    const { components, templateType } = ctx.request.body;
    
    if (!components) {
      ctx.status = 400;
      ctx.body = { success: false, message: '缺少必要的组件数据' };
      return;
    }
    
    try {
      let renderedHtml;
      let renderTime;
      let performanceRating;
      
      // 记录开始时间
      const startTime = Date.now();
      
      if (templateType === 'xtemplate') {
        renderedHtml = await service.grapesjs.renderWithXTemplate(components);
      } else {
        renderedHtml = await service.grapesjs.renderWithGrapesJs(components);
      }
      
      // 计算渲染时间（毫秒）
      renderTime = Date.now() - startTime;
      
      // 评估性能：低于100ms为优，高于100ms为不及格
      performanceRating = renderTime < 100 ? '优' : '不及格';
      
      ctx.body = {
        success: true,
        html: renderedHtml,
        performance: {
          renderTime: renderTime,
          rating: performanceRating
        }
      };
    } catch (error) {
      ctx.logger.error('渲染模板出错:', error);
      ctx.status = 500;
      ctx.body = { success: false, message: '渲染模板出错: ' + error.message };
    }
  }
}

module.exports = GrapesjsController; 