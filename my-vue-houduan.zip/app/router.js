'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  
  // 渲染首页
  router.get('/', controller.home.index);
  
  // GrapesJS JSON 解析与渲染相关路由
  router.post('/api/parse-json', controller.grapesjs.parseJson);
  router.post('/api/render-template', controller.grapesjs.renderTemplate);
  
  // 获取示例 JSON 数据的路由
  router.get('/api/mock-data', controller.mock.getData);
}; 