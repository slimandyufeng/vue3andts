'use strict';

const Service = require('egg').Service;

class MockService extends Service {
  /**
   * 生成模拟的 GrapesJS JSON 数据
   * @param {string} type - 模拟数据类型 ('grapesjs', 'xtemplate', 'mixed')
   * @return {Object} 模拟的 GrapesJS JSON 数据
   */
  async generateMockData(type) {
    switch (type) {
      case 'grapesjs':
        return this.generateGrapesJsMockData();
      case 'xtemplate':
        return this.generateXTemplateMockData();
      case 'mixed':
      default:
        return this.generateMixedMockData();
    }
  }
  
  /**
   * 生成 GrapesJS 原生组件的模拟数据
   * @return {Object} 模拟数据
   */
  generateGrapesJsMockData() {
    return {
      components: [
        {
          type: 'wrapper',
          tagName: 'div',
          attributes: {
            id: 'wrapper',
            class: 'gjs-wrapper',
            style: {
              width: '100%',
              'max-width': '1200px',
              margin: '0 auto',
              padding: '20px'
            }
          },
          components: [
            {
              type: 'header',
              tagName: 'header',
              attributes: {
                class: 'gjs-header',
                style: {
                  padding: '20px 0',
                  'text-align': 'center',
                  'background-color': '#f8f9fa',
                  'margin-bottom': '20px'
                }
              },
              components: [
                {
                  type: 'heading',
                  tagName: 'h1',
                  content: 'GrapesJS 原生组件示例',
                  attributes: {
                    style: {
                      color: '#333',
                      'font-size': '32px'
                    }
                  }
                },
                {
                  type: 'paragraph',
                  tagName: 'p',
                  content: '这是一个使用 GrapesJS 原生组件构建的复杂页面示例',
                  attributes: {
                    style: {
                      color: '#666',
                      'font-size': '16px',
                      'margin-top': '10px'
                    }
                  }
                }
              ]
            },
            {
              type: 'section',
              tagName: 'section',
              attributes: {
                class: 'gjs-feature-section',
                style: {
                  display: 'flex',
                  'flex-wrap': 'wrap',
                  'justify-content': 'space-between',
                  'margin-bottom': '30px'
                }
              },
              components: Array(4).fill().map((_, i) => ({
                type: 'feature',
                tagName: 'div',
                attributes: {
                  class: 'gjs-feature',
                  style: {
                    width: 'calc(25% - 20px)',
                    padding: '20px',
                    'background-color': '#fff',
                    'box-shadow': '0 2px 4px rgba(0,0,0,0.1)',
                    'border-radius': '4px',
                    'text-align': 'center'
                  }
                },
                components: [
                  {
                    type: 'icon',
                    tagName: 'div',
                    attributes: {
                      class: 'gjs-icon',
                      style: {
                        'font-size': '48px',
                        color: '#3498db',
                        'margin-bottom': '15px'
                      }
                    },
                    content: `<i class="fa fa-${['star', 'heart', 'bell', 'envelope'][i]}"></i>`
                  },
                  {
                    type: 'heading',
                    tagName: 'h3',
                    content: `特性 ${i + 1}`,
                    attributes: {
                      style: {
                        'font-size': '20px',
                        'margin-bottom': '10px'
                      }
                    }
                  },
                  {
                    type: 'paragraph',
                    tagName: 'p',
                    content: `这是特性 ${i + 1} 的描述文本，可以在这里添加更多内容。`,
                    attributes: {
                      style: {
                        'font-size': '14px',
                        color: '#777'
                      }
                    }
                  }
                ]
              }))
            },
            {
              type: 'content',
              tagName: 'section',
              attributes: {
                class: 'gjs-content-section',
                style: {
                  display: 'flex',
                  'margin-bottom': '30px'
                }
              },
              components: [
                {
                  type: 'main-content',
                  tagName: 'div',
                  attributes: {
                    class: 'gjs-main-content',
                    style: {
                      flex: '2',
                      padding: '20px',
                      'background-color': '#fff',
                      'box-shadow': '0 2px 4px rgba(0,0,0,0.1)',
                      'border-radius': '4px',
                      'margin-right': '20px'
                    }
                  },
                  components: Array(3).fill().map((_, i) => ({
                    type: 'article',
                    tagName: 'article',
                    attributes: {
                      class: 'gjs-article',
                      style: {
                        'margin-bottom': '25px',
                        'padding-bottom': '25px',
                        'border-bottom': i < 2 ? '1px solid #eee' : 'none'
                      }
                    },
                    components: [
                      {
                        type: 'heading',
                        tagName: 'h2',
                        content: `文章标题 ${i + 1}`,
                        attributes: {
                          style: {
                            'font-size': '24px',
                            'margin-bottom': '15px',
                            color: '#333'
                          }
                        }
                      },
                      {
                        type: 'paragraph',
                        tagName: 'p',
                        content: '这是文章的内容，这里可以放置很多文字，说明文章的主要内容和观点。这只是示例文本，实际使用时会被替换为实际内容。',
                        attributes: {
                          style: {
                            'line-height': '1.6',
                            'margin-bottom': '15px'
                          }
                        }
                      },
                      {
                        type: 'paragraph',
                        tagName: 'p',
                        content: '这是第二段落，提供更多的信息和细节。文章可以包含多个段落，以便更好地组织内容。',
                        attributes: {
                          style: {
                            'line-height': '1.6',
                            'margin-bottom': '15px'
                          }
                        }
                      },
                      {
                        type: 'button',
                        tagName: 'button',
                        content: '阅读更多',
                        attributes: {
                          class: 'gjs-button',
                          style: {
                            background: '#3498db',
                            color: '#fff',
                            border: 'none',
                            padding: '10px 15px',
                            'border-radius': '4px',
                            cursor: 'pointer'
                          }
                        }
                      }
                    ]
                  }))
                },
                {
                  type: 'sidebar',
                  tagName: 'aside',
                  attributes: {
                    class: 'gjs-sidebar',
                    style: {
                      flex: '1',
                      padding: '20px',
                      'background-color': '#fff',
                      'box-shadow': '0 2px 4px rgba(0,0,0,0.1)',
                      'border-radius': '4px'
                    }
                  },
                  components: [
                    {
                      type: 'heading',
                      tagName: 'h3',
                      content: '侧边栏',
                      attributes: {
                        style: {
                          'font-size': '20px',
                          'margin-bottom': '15px',
                          'padding-bottom': '10px',
                          'border-bottom': '1px solid #eee'
                        }
                      }
                    },
                    {
                      type: 'list',
                      tagName: 'ul',
                      attributes: {
                        class: 'gjs-list',
                        style: {
                          'list-style': 'none',
                          padding: '0',
                          margin: '0'
                        }
                      },
                      components: Array(5).fill().map((_, i) => ({
                        type: 'list-item',
                        tagName: 'li',
                        attributes: {
                          style: {
                            padding: '10px 0',
                            'border-bottom': i < 4 ? '1px solid #f5f5f5' : 'none'
                          }
                        },
                        components: [
                          {
                            type: 'link',
                            tagName: 'a',
                            content: `链接项目 ${i + 1}`,
                            attributes: {
                              href: '#',
                              style: {
                                color: '#3498db',
                                'text-decoration': 'none'
                              }
                            }
                          }
                        ]
                      }))
                    },
                    {
                      type: 'widget',
                      tagName: 'div',
                      attributes: {
                        class: 'gjs-widget',
                        style: {
                          'margin-top': '20px',
                          padding: '15px',
                          'background-color': '#f8f9fa',
                          'border-radius': '4px'
                        }
                      },
                      components: [
                        {
                          type: 'heading',
                          tagName: 'h4',
                          content: '关于我们',
                          attributes: {
                            style: {
                              'font-size': '16px',
                              'margin-bottom': '10px'
                            }
                          }
                        },
                        {
                          type: 'paragraph',
                          tagName: 'p',
                          content: '这是一个关于我们的小部件，提供有关网站或公司的简短描述。',
                          attributes: {
                            style: {
                              'font-size': '14px',
                              color: '#777'
                            }
                          }
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            {
              type: 'gallery',
              tagName: 'section',
              attributes: {
                class: 'gjs-gallery',
                style: {
                  'margin-bottom': '30px'
                }
              },
              components: [
                {
                  type: 'heading',
                  tagName: 'h2',
                  content: '图片画廊',
                  attributes: {
                    style: {
                      'font-size': '28px',
                      'margin-bottom': '20px',
                      'text-align': 'center'
                    }
                  }
                },
                {
                  type: 'gallery-container',
                  tagName: 'div',
                  attributes: {
                    class: 'gjs-gallery-container',
                    style: {
                      display: 'flex',
                      'flex-wrap': 'wrap',
                      'justify-content': 'space-between'
                    }
                  },
                  components: Array(6).fill().map((_, i) => ({
                    type: 'gallery-item',
                    tagName: 'div',
                    attributes: {
                      class: 'gjs-gallery-item',
                      style: {
                        width: 'calc(33.333% - 15px)',
                        'margin-bottom': '20px',
                        'border-radius': '4px',
                        overflow: 'hidden',
                        'box-shadow': '0 2px 4px rgba(0,0,0,0.1)'
                      }
                    },
                    components: [
                      {
                        type: 'image',
                        tagName: 'img',
                        attributes: {
                          src: `https://picsum.photos/id/${10 + i}/400/300`,
                          alt: `图片 ${i + 1}`,
                          style: {
                            width: '100%',
                            height: 'auto',
                            display: 'block'
                          }
                        }
                      },
                      {
                        type: 'caption',
                        tagName: 'div',
                        attributes: {
                          class: 'gjs-caption',
                          style: {
                            padding: '10px',
                            'background-color': '#fff'
                          }
                        },
                        components: [
                          {
                            type: 'heading',
                            tagName: 'h4',
                            content: `图片标题 ${i + 1}`,
                            attributes: {
                              style: {
                                'margin-bottom': '5px',
                                'font-size': '16px'
                              }
                            }
                          },
                          {
                            type: 'paragraph',
                            tagName: 'p',
                            content: '图片描述文本，简要说明图片的内容或相关信息。',
                            attributes: {
                              style: {
                                'font-size': '14px',
                                color: '#777',
                                margin: '0'
                              }
                            }
                          }
                        ]
                      }
                    ]
                  }))
                }
              ]
            },
            {
              type: 'footer',
              tagName: 'footer',
              attributes: {
                class: 'gjs-footer',
                style: {
                  'background-color': '#2c3e50',
                  color: '#ecf0f1',
                  padding: '30px 0 20px',
                  'text-align': 'center'
                }
              },
              components: [
                {
                  type: 'container',
                  tagName: 'div',
                  attributes: {
                    class: 'gjs-footer-container',
                    style: {
                      display: 'flex',
                      'flex-wrap': 'wrap',
                      'justify-content': 'space-between',
                      'max-width': '1200px',
                      margin: '0 auto',
                      padding: '0 20px'
                    }
                  },
                  components: Array(3).fill().map((_, i) => ({
                    type: 'footer-column',
                    tagName: 'div',
                    attributes: {
                      class: 'gjs-footer-column',
                      style: {
                        width: 'calc(33.333% - 30px)'
                      }
                    },
                    components: [
                      {
                        type: 'heading',
                        tagName: 'h3',
                        content: ['关于我们', '服务', '联系方式'][i],
                        attributes: {
                          style: {
                            'font-size': '18px',
                            'margin-bottom': '15px',
                            'padding-bottom': '10px',
                            'border-bottom': '1px solid #34495e'
                          }
                        }
                      },
                      {
                        type: 'paragraph',
                        tagName: 'p',
                        content: i === 0 
                          ? '我们是一个致力于提供高质量服务的公司，我们的目标是客户满意。'
                          : i === 1 
                            ? '我们提供各种服务，包括设计、开发、咨询等多个领域。'
                            : '地址: 示例街道123号<br>电话: 123-456-7890<br>邮箱: example@example.com',
                        attributes: {
                          style: {
                            'font-size': '14px',
                            'line-height': '1.6'
                          }
                        }
                      }
                    ]
                  }))
                },
                {
                  type: 'copyright',
                  tagName: 'div',
                  attributes: {
                    class: 'gjs-copyright',
                    style: {
                      'margin-top': '30px',
                      'padding-top': '20px',
                      'border-top': '1px solid #34495e',
                      'font-size': '14px'
                    }
                  },
                  content: '© 2025 GrapesJS 示例。版权所有。'
                }
              ]
            }
          ]
        }
      ],
      styles: [
        {
          selectors: ['body'],
          style: {
            margin: 0,
            padding: 0,
            'font-family': 'Arial, sans-serif',
            'background-color': '#f5f5f5',
            color: '#333'
          }
        },
        {
          selectors: ['.gjs-button:hover'],
          style: {
            'background-color': '#2980b9'
          }
        }
      ],
      assets: []
    };
  }
  
  /**
   * 生成 XTemplate 模板组件的模拟数据
   * @return {Object} 模拟数据
   */
  generateXTemplateMockData() {
    return {
      components: [
        {
          type: 'wrapper',
          tagName: 'div',
          attributes: {
            id: 'wrapper',
            class: 'xt-wrapper',
            style: {
              width: '100%',
              'max-width': '1200px',
              margin: '0 auto',
              padding: '20px'
            }
          },
          components: [
            {
              type: 'header',
              tagName: 'header',
              attributes: {
                class: 'xt-header',
                style: {
                  padding: '20px 0',
                  'text-align': 'center',
                  'background-color': '#f8f9fa',
                  'margin-bottom': '20px'
                }
              },
              components: [
                {
                  type: 'heading',
                  tagName: 'h1',
                  content: '{{title}}',
                  attributes: {
                    style: {
                      color: '#333',
                      'font-size': '32px'
                    }
                  }
                },
                {
                  type: 'paragraph',
                  tagName: 'p',
                  content: '欢迎 {{user.name}}，这是一个使用 XTemplate 构建的页面示例',
                  attributes: {
                    style: {
                      color: '#666',
                      'font-size': '16px',
                      'margin-top': '10px'
                    }
                  }
                }
              ]
            },
            {
              type: 'section',
              tagName: 'section',
              attributes: {
                class: 'xt-list-section',
                style: {
                  'margin-bottom': '30px'
                }
              },
              components: [
                {
                  type: 'heading',
                  tagName: 'h2',
                  content: '项目列表',
                  attributes: {
                    style: {
                      'font-size': '24px',
                      'margin-bottom': '15px'
                    }
                  }
                },
                {
                  type: 'list',
                  tagName: 'ul',
                  attributes: {
                    class: 'xt-list',
                    style: {
                      'list-style': 'none',
                      padding: '0',
                      margin: '0'
                    }
                  },
                  content: `
                    {{#each items}}
                      <li style="padding: 15px; margin-bottom: 10px; background-color: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.1); border-radius: 4px;">
                        <h3 style="margin-top: 0; margin-bottom: 10px;">{{name}}</h3>
                        <p style="margin: 0;">项目 ID: {{id}}</p>
                      </li>
                    {{/each}}
                  `
                }
              ]
            },
            {
              type: 'user-info',
              tagName: 'section',
              attributes: {
                class: 'xt-user-info',
                style: {
                  padding: '20px',
                  'background-color': '#fff',
                  'box-shadow': '0 2px 4px rgba(0,0,0,0.1)',
                  'border-radius': '4px',
                  'margin-bottom': '30px'
                }
              },
              content: `
                <h2 style="margin-top: 0;">用户信息</h2>
                <div style="display: flex; flex-wrap: wrap;">
                  <div style="flex: 1; min-width: 200px;">
                    <h3>个人资料</h3>
                    <p><strong>姓名:</strong> {{user.name}}</p>
                    <p><strong>年龄:</strong> {{user.age}}</p>
                    {{#if user.email}}
                      <p><strong>邮箱:</strong> {{user.email}}</p>
                    {{/if}}
                  </div>
                  <div style="flex: 1; min-width: 200px;">
                    <h3>统计信息</h3>
                    <p><strong>项目数量:</strong> {{items.length}}</p>
                    {{#if user.lastLogin}}
                      <p><strong>上次登录:</strong> {{user.lastLogin}}</p>
                    {{else}}
                      <p><strong>上次登录:</strong> 未知</p>
                    {{/if}}
                  </div>
                </div>
              `
            },
            {
              type: 'content',
              tagName: 'section',
              attributes: {
                class: 'xt-content',
                style: {
                  'margin-bottom': '30px'
                }
              },
              components: [
                {
                  type: 'heading',
                  tagName: 'h2',
                  content: '{{content}}',
                  attributes: {
                    style: {
                      'font-size': '24px',
                      'margin-bottom': '15px'
                    }
                  }
                },
                {
                  type: 'rich-content',
                  tagName: 'div',
                  attributes: {
                    class: 'xt-rich-content',
                    style: {
                      padding: '20px',
                      'background-color': '#fff',
                      'box-shadow': '0 2px 4px rgba(0,0,0,0.1)',
                      'border-radius': '4px'
                    }
                  },
                  content: `
                    <p>这是一个使用 XTemplate 模板引擎的复杂示例。以下是一些动态内容：</p>
                    
                    <div style="margin: 20px 0;">
                      {{#if user.admin}}
                        <div style="background-color: #d4edda; color: #155724; padding: 10px; border-radius: 4px;">
                          您拥有管理员权限
                        </div>
                      {{else}}
                        <div style="background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px;">
                          您没有管理员权限
                        </div>
                      {{/if}}
                    </div>
                    
                    <h3>条件渲染示例</h3>
                    {{#if items.length > 0}}
                      <p>您有 {{items.length}} 个项目</p>
                      <p>第一个项目是: {{items.0.name}}</p>
                    {{else}}
                      <p>您没有任何项目</p>
                    {{/if}}
                    
                    <h3>循环嵌套示例</h3>
                    {{#each items}}
                      <div style="margin-bottom: 15px; padding: 10px; background-color: #f8f9fa; border-radius: 4px;">
                        <h4 style="margin-top: 0;">{{name}}</h4>
                        <p>ID: {{id}}</p>
                        {{#if tags}}
                          <div>
                            标签:
                            {{#each tags}}
                              <span style="display: inline-block; margin-right: 5px; padding: 2px 8px; background-color: #e9ecef; border-radius: 10px; font-size: 12px;">{{this}}</span>
                            {{/each}}
                          </div>
                        {{/if}}
                      </div>
                    {{/each}}
                  `
                }
              ]
            },
            {
              type: 'footer',
              tagName: 'footer',
              attributes: {
                class: 'xt-footer',
                style: {
                  'background-color': '#2c3e50',
                  color: '#ecf0f1',
                  padding: '20px',
                  'text-align': 'center'
                }
              },
              content: `
                <p>© 2025 XTemplate 示例。版权所有。</p>
                <p>当前用户: {{user.name}}</p>
                {{#if user.admin}}
                  <p><a href="#" style="color: #3498db;">管理控制台</a></p>
                {{/if}}
              `
            }
          ]
        }
      ],
      styles: [
        {
          selectors: ['body'],
          style: {
            margin: 0,
            padding: 0,
            'font-family': 'Arial, sans-serif',
            'background-color': '#f5f5f5',
            color: '#333'
          }
        }
      ],
      assets: []
    };
  }
  
  /**
   * 生成混合 GrapesJS 和 XTemplate 组件的模拟数据
   * @return {Object} 模拟数据
   */
  generateMixedMockData() {
    // 组合 GrapesJS 和 XTemplate 的组件
    const grapesJsData = this.generateGrapesJsMockData();
    const xTemplateData = this.generateXTemplateMockData();
    
    const mixedComponents = [
      {
        type: 'wrapper',
        tagName: 'div',
        attributes: {
          id: 'mixed-wrapper',
          style: {
            width: '100%',
            'max-width': '1200px',
            margin: '0 auto',
            padding: '20px'
          }
        },
        components: [
          {
            type: 'header',
            tagName: 'header',
            attributes: {
              style: {
                padding: '20px 0',
                'text-align': 'center',
                'background-color': '#f8f9fa',
                'margin-bottom': '20px'
              }
            },
            components: [
              {
                type: 'heading',
                tagName: 'h1',
                content: '混合 GrapesJS 和 XTemplate 组件',
                attributes: {
                  style: {
                    color: '#333',
                    'font-size': '32px'
                  }
                }
              },
              {
                type: 'paragraph',
                tagName: 'p',
                content: '欢迎 {{user.name}}，这是一个混合使用两种类型组件的示例',
                attributes: {
                  style: {
                    color: '#666',
                    'font-size': '16px',
                    'margin-top': '10px'
                  }
                }
              }
            ]
          },
          // 添加一个 GrapesJS 原生的特性部分
          grapesJsData.components[0].components[1],
          // 添加一个 XTemplate 的用户信息部分
          xTemplateData.components[0].components[2],
          // 添加一个 GrapesJS 原生的内容部分
          grapesJsData.components[0].components[2],
          // 添加一个 XTemplate 的项目列表部分
          xTemplateData.components[0].components[1],
          // 添加混合的页脚
          {
            type: 'footer',
            tagName: 'footer',
            attributes: {
              style: {
                'background-color': '#2c3e50',
                color: '#ecf0f1',
                padding: '20px',
                'text-align': 'center'
              }
            },
            content: `
              <div>
                <p>© 2025 混合示例。版权所有。</p>
                <p>当前有 {{items.length}} 个项目</p>
                <p>性能测试：渲染了大量组件</p>
              </div>
            `
          }
        ]
      }
    ];
    
    // 添加更多组件用于性能测试
    for (let i = 0; i < 10; i++) {
      mixedComponents[0].components.push({
        type: 'performance-test',
        tagName: 'section',
        attributes: {
          class: `test-section-${i}`,
          style: {
            padding: '15px',
            'margin-bottom': '10px',
            'background-color': i % 2 === 0 ? '#f8f9fa' : '#fff',
            'border-radius': '4px'
          }
        },
        components: [
          {
            type: 'heading',
            tagName: 'h3',
            content: `性能测试段落 ${i + 1}`,
            attributes: {
              style: {
                'margin-top': '0',
                'font-size': '18px'
              }
            }
          },
          {
            type: 'container',
            tagName: 'div',
            attributes: {
              style: {
                display: 'flex',
                'flex-wrap': 'wrap',
                'gap': '10px'
              }
            },
            components: Array(5).fill().map((_, j) => ({
              type: i % 2 === 0 ? 'grapesjs-item' : 'xtemplate-item',
              tagName: 'div',
              attributes: {
                style: {
                  flex: '1',
                  'min-width': '150px',
                  padding: '10px',
                  'background-color': '#f0f0f0',
                  'border-radius': '4px'
                }
              },
              content: i % 2 === 0 
                ? `性能测试项 ${j + 1} - GrapesJS`
                : `{{#if items.${j}}}项目名: {{items.${j}.name}}{{else}}项目 ${j + 1}{{/if}}`
            }))
          }
        ]
      });
    }
    
    return {
      components: mixedComponents,
      styles: [
        ...grapesJsData.styles,
        ...xTemplateData.styles
      ],
      assets: []
    };
  }
}

module.exports = MockService; 