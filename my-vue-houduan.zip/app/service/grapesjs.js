'use strict';

const Service = require('egg').Service;
const fs = require('fs');
const { JSDOM } = require('jsdom');
// 移除 XTemplate 引用，将使用备选方案
// const XTemplate = require('xtemplate');
const { chain } = require('stream-chain');
const { parser } = require('stream-json');
const { pick } = require('stream-json/filters/Pick');
const { streamArray } = require('stream-json/streamers/StreamArray');
const { streamObject } = require('stream-json/streamers/StreamObject');

class GrapesjsService extends Service {
  /**
   * 使用流式处理解析大型 JSON 文件
   * @param {string} filePath - JSON 文件路径
   * @return {Promise<Object>} 解析后的 JSON 对象
   */
  async parseJsonStream(filePath) {
    return new Promise((resolve, reject) => {
      const result = { components: [], styles: {} };
      
      const pipeline = chain([
        fs.createReadStream(filePath),
        parser(),
        streamObject(),
      ]);
      
      pipeline.on('data', data => {
        const { key, value } = data;
        
        if (key === 'components') {
          result.components = value;
        } else if (key === 'styles') {
          result.styles = value;
        }
      });
      
      pipeline.on('end', () => {
        resolve(result);
      });
      
      pipeline.on('error', err => {
        reject(err);
      });
    });
  }
  
  /**
   * 检测模板类型（GrapesJS 原生或 XTemplate）
   * @param {Object} jsonData - 解析后的 JSON 数据
   * @return {string} 模板类型 - 'grapesjs' 或 'xtemplate'
   */
  detectTemplateType(jsonData) {
    if (!jsonData.components || !Array.isArray(jsonData.components)) {
      return 'grapesjs';
    }
    
    // 检查是否有包含 XTemplate 语法的组件
    const hasXTemplate = jsonData.components.some(component => {
      if (component.content && typeof component.content === 'string') {
        return component.content.includes('{{') && component.content.includes('}}');
      }
      return false;
    });
    
    return hasXTemplate ? 'xtemplate' : 'grapesjs';
  }
  
  /**
   * 使用 GrapesJS 原生方式渲染组件
   * @param {Array} components - 组件数组
   * @return {Promise<string>} 渲染后的 HTML
   */
  async renderWithGrapesJs(components) {
    const dom = new JSDOM('<!DOCTYPE html><html><body></body></html>');
    const { document } = dom.window;
    
    const renderComponent = (component, parent) => {
      if (typeof component === 'string') {
        const textNode = document.createTextNode(component);
        parent.appendChild(textNode);
        return;
      }
      
      const el = document.createElement(component.tagName || 'div');
      
      // 处理属性
      if (component.attributes) {
        Object.entries(component.attributes).forEach(([key, value]) => {
          if (key === 'style' && typeof value === 'object') {
            Object.entries(value).forEach(([prop, val]) => {
              el.style[prop] = val;
            });
          } else {
            el.setAttribute(key, value);
          }
        });
      }
      
      // 处理内容
      if (component.content) {
        if (typeof component.content === 'string') {
          el.innerHTML = component.content;
        } else if (Array.isArray(component.content)) {
          component.content.forEach(child => renderComponent(child, el));
        }
      }
      
      // 处理子组件
      if (component.components && Array.isArray(component.components)) {
        component.components.forEach(child => renderComponent(child, el));
      }
      
      parent.appendChild(el);
    };
    
    components.forEach(component => renderComponent(component, document.body));
    
    return document.body.innerHTML;
  }
  
  /**
   * 使用简化的模板渲染取代 XTemplate
   * @param {Array} components - 组件数组
   * @return {Promise<string>} 渲染后的 HTML
   */
  async renderWithXTemplate(components) {
    // 将组件转换为 HTML 字符串模板
    const templateString = this.componentsToTemplateString(components);
    
    // 模拟数据
    const data = {
      user: { name: '测试用户', age: 30 },
      items: [
        { id: 1, name: '项目 1' },
        { id: 2, name: '项目 2' },
        { id: 3, name: '项目 3' },
      ],
      title: '测试标题',
      content: '这是内容',
    };
    
    // 使用简单的模板替换
    return this.renderTemplate(templateString, data);
  }
  
  /**
   * 简单的模板渲染函数
   * @param {string} template - 模板字符串
   * @param {Object} data - 数据对象
   * @return {string} 渲染后的 HTML
   */
  renderTemplate(template, data) {
    // 替换简单变量，如 {{user.name}}、{{title}} 等
    let result = template.replace(/\{\{([^}]+)\}\}/g, (match, path) => {
      const keys = path.trim().split('.');
      let value = data;
      
      for (const key of keys) {
        if (value && value[key] !== undefined) {
          value = value[key];
        } else {
          return match; // 如果找不到值，保留原始模板变量
        }
      }
      
      return value;
    });
    
    // 简化处理 each 循环
    // 匹配 {{#each items}} 内容 {{/each}}
    result = result.replace(/\{\{#each\s+([^}]+)\}\}([\s\S]*?)\{\{\/each\}\}/g, (match, path, content) => {
      const keys = path.trim().split('.');
      let array = data;
      
      // 获取数组数据
      for (const key of keys) {
        if (array && array[key] !== undefined) {
          array = array[key];
        } else {
          return ''; // 如果找不到数组，返回空字符串
        }
      }
      
      if (!Array.isArray(array)) {
        return '';
      }
      
      // 对数组中的每一项渲染内容
      return array.map(item => {
        // 在当前项的上下文中渲染内容
        return content.replace(/\{\{([^}]+)\}\}/g, (m, p) => {
          if (p.trim() === 'this') {
            return item;
          }
          
          const itemKeys = p.trim().split('.');
          let value = item;
          
          for (const key of itemKeys) {
            if (value && value[key] !== undefined) {
              value = value[key];
            } else {
              return m; // 如果找不到值，保留原始模板变量
            }
          }
          
          return value;
        });
      }).join('');
    });
    
    // 简单处理 if 条件
    // 匹配 {{#if condition}} 内容 {{/if}}
    result = result.replace(/\{\{#if\s+([^}]+)\}\}([\s\S]*?)(?:\{\{else\}\}([\s\S]*?))?\{\{\/if\}\}/g, (match, condition, ifContent, elseContent = '') => {
      let conditionMet = false;
      
      // 解析条件
      if (condition.includes('>') || condition.includes('<') || condition.includes('==') || condition.includes('!=')) {
        // 比较操作
        const parts = condition.split(/([><=!]+)/).map(p => p.trim());
        const left = this.evaluatePath(parts[0], data);
        const operator = parts[1];
        const right = this.evaluatePath(parts[2], data);
        
        switch (operator) {
          case '>': conditionMet = left > right; break;
          case '<': conditionMet = left < right; break;
          case '>=': conditionMet = left >= right; break;
          case '<=': conditionMet = left <= right; break;
          case '==': conditionMet = left == right; break;
          case '===': conditionMet = left === right; break;
          case '!=': conditionMet = left != right; break;
          case '!==': conditionMet = left !== right; break;
          default: conditionMet = false;
        }
      } else {
        // 简单条件，检查值是否存在且非空
        const value = this.evaluatePath(condition, data);
        conditionMet = Boolean(value);
      }
      
      // 根据条件返回相应内容
      return conditionMet ? this.renderTemplate(ifContent, data) : this.renderTemplate(elseContent, data);
    });
    
    return result;
  }
  
  /**
   * 评估路径表达式，获取数据对象中的值
   * @param {string} path - 路径表达式
   * @param {Object} data - 数据对象
   * @return {*} 路径对应的值
   */
  evaluatePath(path, data) {
    if (!path) return undefined;
    
    // 处理字面量
    if (path === 'true') return true;
    if (path === 'false') return false;
    if (path === 'null') return null;
    if (path === 'undefined') return undefined;
    
    // 处理数字
    if (/^-?\d+(\.\d+)?$/.test(path)) {
      return parseFloat(path);
    }
    
    // 处理路径表达式
    const keys = path.trim().split('.');
    let value = data;
    
    for (const key of keys) {
      if (value && value[key] !== undefined) {
        value = value[key];
      } else {
        return undefined;
      }
    }
    
    return value;
  }
  
  /**
   * 将组件转换为模板字符串
   * @param {Array} components - 组件数组
   * @return {string} 模板字符串
   */
  componentsToTemplateString(components) {
    const processComponent = component => {
      if (typeof component === 'string') {
        return component;
      }
      
      const tagName = component.tagName || 'div';
      let attributes = '';
      
      // 处理属性
      if (component.attributes) {
        attributes = Object.entries(component.attributes)
          .map(([key, value]) => {
            if (key === 'style' && typeof value === 'object') {
              const styleString = Object.entries(value)
                .map(([prop, val]) => `${prop}:${val}`)
                .join(';');
              return `style="${styleString}"`;
            }
            return `${key}="${value}"`;
          })
          .join(' ');
      }
      
      // 处理内容和子组件
      let content = '';
      if (component.content) {
        if (typeof component.content === 'string') {
          content = component.content;
        } else if (Array.isArray(component.content)) {
          content = component.content.map(processComponent).join('');
        }
      }
      
      if (component.components && Array.isArray(component.components)) {
        content += component.components.map(processComponent).join('');
      }
      
      return `<${tagName}${attributes ? ' ' + attributes : ''}>${content}</${tagName}>`;
    };
    
    return components.map(processComponent).join('');
  }
}

module.exports = GrapesjsService; 